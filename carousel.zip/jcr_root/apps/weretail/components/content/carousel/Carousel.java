package com.sei.ea.capella.core.models;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;

import com.adobe.cq.sightly.WCMUsePojo;

public class Carousel extends WCMUsePojo {
	@ChildResource
	private List<Resource> slideList = new ArrayList<>();

	public List<Resource> getSlideList() {
		return slideList;
	}
	@Override
    public void activate() throws Exception {
		Iterator<Resource> iter = getResource().getChild("slides").getChildren().iterator();
		while(iter.hasNext()) {
			slideList.add(iter.next());
		}
	}
}
