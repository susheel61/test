$(function() {
    if($('.performance.overlap').length) {
        function overlapSection() {
            var height = $('.performance.overlap').outerHeight();
            $('.performance.overlap').css('top',height/2);
        }
        $(window).on('resize',overlapSection);
        overlapSection();
    }
});